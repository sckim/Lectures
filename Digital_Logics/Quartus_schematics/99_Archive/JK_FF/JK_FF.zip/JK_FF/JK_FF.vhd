library ieee;
use ieee.std_logic_1164.all;

entity JK_FF is 
      port( K, Clk, J, Enable : in std_logic;
            Q         : out std_logic);
end JK_FF;

architecture sample of JK_FF is 
      signal Q_test : std_logic;
begin 
      process(Clk, Enable)
      begin
           if (Enable = '0') then
               Q_test <= '0';
           elsif rising_edge(Clk) then 
               if (J = '0' and K = '0') then
                    Q_test <= Q_test;
               elsif (J = '1' and K = '0') then
                    Q_test <= '1';
               elsif (J = '0' and K = '1') then
                    Q_test <= '0';
               elsif (J = '1' and K = '1') then 
                    Q_test <= not Q_test;
               end if;
           end if;
      Q <= Q_test;
      end process;
end sample;