library ieee;
use ieee.std_logic_1164.all;

entity RN_Generator is 
       port( SW             : in std_logic_vector(1 downto 0); --SW[1] : Clock Pulse, SW[0] : Prset Switch
             Qa, Qb, Qc, Qd : out std_logic);
end RN_Generator;

architecture sample of RN_Generator is
       signal Q1, Q2, Q3, Q4, Da : std_logic;
begin 
       process(SW(0), SW(1))
       begin
             if (SW(0) = '0') then 
                 Q1 <= '1';
                 Q2 <= '0';
                 Q3 <= '0';
                 Q4 <= '0';
             elsif rising_edge(SW(1))then                 
                 Q4 <= Q3;
                 Q3 <= Q2;
                 Q2 <= Q1; 
                 Q1 <= Q3 XOR Q4; 
             end if;
       end process;     
             
       Qa <= Q1;
       Qb <= Q2;
       Qc <= Q3;
       Qd <= Q4;          
end sample;