library ieee;
use ieee.std_logic_1164.all;

entity SR_Latch is 
         port( R_g, S_g   : in bit;
               Q, Q_bar   : inout bit);
end SR_Latch;

architecture sample of SR_Latch is 
begin
      Q <= not R_g or not Q_bar;
      Q_bar <= not S_g or not Q;
end sample;