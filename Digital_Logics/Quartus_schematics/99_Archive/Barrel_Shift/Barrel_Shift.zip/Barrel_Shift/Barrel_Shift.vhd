library ieee;
use ieee.std_logic_1164.all;

entity Barrel_Shift is 
    generic (N :integer :=8);
    port(
        clk, reset      : in std_logic;
        direction       : in std_logic_vector(1 downto 0);
        ctrl            : in std_logic_vector(1 downto 0);              
        data            : in std_logic_vector(N-1 downto 0);
        q_reg           : out std_logic_vector(N-1 downto 0));
end Barrel_Shift;


architecture sample of Barrel_Shift is
       signal s_reg, s_next : std_logic_vector(N-1 downto 0);
begin
       process(clk, reset)
       begin
          if(reset='1') then
              s_reg <= (others=>'0'); 
          elsif rising_edge(clk) then
              s_reg <= s_next; 
          end if;
       end process;
       
       process (ctrl, direction,  s_reg)
       begin
        case ctrl is
            when "00" =>
                s_next <= s_reg; 
            when "01" =>
                if direction = "01" then 
                    s_next <= data(N-1) & s_reg(N-1 downto 1); 
                elsif direction = "10" then
                    s_next <= data(N-2) & data(N-1) & s_reg(N-1 downto 2);
                elsif direction = "11" then
                    s_next <= data(N-3) & data(N-2) & data(N-1) & s_reg(N-1 downto 3);
                else 
                    s_next <= s_reg;
                end if;
            when "10" =>
                if direction = "01" then 
                    s_next <= s_reg(N-2 downto 0) & data(0); 
                elsif direction = "10" then
                    s_next <= s_reg(N-3 downto 0) & data(0) & data(1);
                elsif direction = "11" then
                    s_next <= s_reg(N-4 downto 0) & data(0) & data(1) & data(2);
                else 
                    s_next <= s_reg;  
                end if;            
            when others =>
                s_next <= data;  
        end case;
       end process; 
    
       q_reg <= s_reg;
end sample;


