library ieee;
use ieee.std_logic_1164.all;

entity T_FF is 
     port( Clk, T, Enable  : in std_logic;
           Q       : out std_logic);
end T_FF;

architecture sample of T_FF is
     signal Q_m : std_logic;
begin 
     process(Clk, Enable)
     begin
           if (Enable = '0') then 
               Q_m <= '0';
           elsif rising_edge(Clk) then 
               if (T = '1') then
                   Q_m <= not Q_m;
               else 
                   Q_m <= Q_m;
               end if;
           end if;
     Q <= Q_m;
     end process;
end sample;