library ieee;
use ieee.std_logic_1164.all;

package my_package is
	constant adder_width	: integer:=4;
	constant result_width	: integer:=5;
	
	subtype adder_value is integer range 0 to 2**adder_width-1;
	subtype result_value is integer range 0 to 2**result_width-1;
end my_package;

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use work.my_package.all;

entity FourBitFullAdder is
	port( a, b					: in adder_value;
		  sum_out				: out result_value);
end FourBitFullAdder;

architecture design of FourBitFullAdder is
begin
	process(a, b)
		variable sum : integer;
	begin
		sum := a + b;
		sum_out <= sum;
	end process;
end design;