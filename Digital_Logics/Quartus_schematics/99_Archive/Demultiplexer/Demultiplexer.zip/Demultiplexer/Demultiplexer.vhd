library ieee;
use ieee.std_logic_1164.all;

entity Demultiplexer is 
        port( s  : in std_logic_vector(1 downto 0);
              i  : in std_logic;
              y  : out std_logic_vector(3 downto 0));
end Demultiplexer;

architecture sample of Demultiplexer is	
        
begin 
        process(s)
        begin
               case s is 
                    when "00" => 
                         y(0) <= '1';
                         y(1) <= '0';
                         y(2) <= '0';
                         y(3) <= '0';                        
                    when "01" => 
                         y(0) <= '0';
                         y(1) <= '1';
                         y(2) <= '0';
                         y(3) <= '0'; 
                    when "10" => 
                         y(0) <= '0';
                         y(1) <= '0';
                         y(2) <= '1';
                         y(3) <= '0'; 
                    when "11" => 
                         y(0) <= '0';
                         y(1) <= '0';
                         y(2) <= '0';
                         y(3) <= '1';
                    
               end case;
        end process;
end sample;		