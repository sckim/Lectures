library ieee;
use ieee.std_logic_1164.all;

entity parallel_to_parallel is
	generic(N : positive := 4);
	port(sin : in std_logic_vector(N-1 downto 0);
		 clk : in std_logic;
		 rst : in std_logic;
		 sout : out std_logic_vector(N-1 downto 0));
end entity parallel_to_parallel;

architecture arc of parallel_to_parallel is
begin
	process (clk) begin
		if rising_edge(clk) then
			if rst = '1' then
				sout <= (others => '0');
			else
				sout <= sin;
			end if;
		end if;
	end process;

end architecture arc;
