library ieee;
use ieee.std_logic_1164.all;

entity serial_to_serial is
	port(clk : in std_logic;
		 clr : in std_logic;
		 sin : in std_logic;
		 sout: inout std_logic_vector(3 downto 0));
end serial_to_serial;

architecture Behavioral of serial_to_serial is
begin
	process(clk,clr)
	begin
		if clr = '1' then
			sout <= "0000";
		elsif clk'event and clk = '1' then
			sout(3) <= sin;
			sout(2 downto 0) <= sout(3 downto 1);
		end if;
	end process;
end Behavioral;