library ieee;
use ieee.std_logic_1164.all;

entity MasterSlave_DFF is 
      port( SW   : in std_logic_vector(1 downto 0);
            LEDR : out std_logic_vector(0 to 0));
end MasterSlave_DFF;

architecture sample of MasterSlave_DFF is 
      component D_FF 
            port( Clk, D : in std_logic;
                  Q      : out std_logic);
      end component; 
      signal Q_m, Q_s : std_logic;
begin 
      U1 : D_FF port map(not SW(1), SW(0), Q_m);
      U2 : D_FF port map(SW(1), Q_m, Q_s);
      
      LEDR(0) <= Q_s;
end sample; 