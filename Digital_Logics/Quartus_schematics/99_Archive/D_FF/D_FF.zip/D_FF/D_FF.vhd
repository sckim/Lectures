library ieee;
use ieee.std_logic_1164.all;

entity D_FF is
     port( Clk, D  : in std_logic;
           Q       : out std_logic);
end D_FF;

architecture sample of D_FF is 
     signal R, R_g, S_g, Qa, Qb : std_logic;
     attribute keep : boolean;
     attribute keep of R, R_g, S_g, Qa, Qb : signal is true;
begin
     R <= not D;
	 S_g <= not (D and Clk);
	 R_g <= not (R and Clk);
	 Qa <= not (S_g and Qb);
	 Qb <= not (R_g and Qa);
	 
	 Q <= Qa;
end sample;
