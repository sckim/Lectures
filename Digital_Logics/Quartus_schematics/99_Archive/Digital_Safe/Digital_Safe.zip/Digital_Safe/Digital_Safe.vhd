LIBRARY ieee;
USE ieee.std_logic_1164.all;


ENTITY Digital_Safe IS
	PORT ( Clk, D : IN	STD_LOGIC;
	 	 Q      : OUT	STD_LOGIC);
END Digital_Safe;

ARCHITECTURE sample OF Digital_Safe IS
	SIGNAL R, R_g, S_g, Qa, Qb : STD_LOGIC ;
	ATTRIBUTE keep: boolean;
	ATTRIBUTE keep of R, R_g, S_g, Qa, Qb : signal is true;
BEGIN	
	R <= NOT D;
	S_g <= NOT (D AND Clk);
	R_g <= NOT (R AND Clk);
	Qa <= NOT (S_g AND Qb);
	Qb <= NOT (R_g AND Qa);

	Q <= Qa;
END sample;
