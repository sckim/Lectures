library ieee;
use ieee.std_logic_1164.all;

entity Digitalsafe_vhdl is
     port( SW   : in std_logic;          
           key1  : in std_logic_vector(9 downto 0);
           key2  : in std_logic_vector(9 downto 0);
           key3  : in std_logic_vector(9 downto 0);
           key4  : in std_logic_vector(9 downto 0);
           pass : out std_logic);
end Digitalsafe_vhdl;

architecture sample of Digitalsafe_vhdl is 
     component Digital_Safe 
		 	 port ( Clk, D	: in	std_logic;
		 	        Q		: out	std_logic);
	 end component;
	 signal Qa, Qb, Qc, Qd, clk1, clk2, clk3, clk4 : std_logic;
begin
     U1 : Digital_Safe port map(clk1, SW, Qa);
     U2 : Digital_Safe port map(clk2, Qa, Qb);
     U3 : Digital_Safe port map(clk3, Qb, Qc);
     U4 : Digital_Safe port map(clk4, Qc, Qd);
	 process(key1, key2, key3, key4)
	 begin
	      
	         if key1 = "0000010000" then 
	               clk1 <= '1'; 
	               clk2 <= '0';
	               clk3 <= '0';
	               clk4 <= '0';                 
	         elsif key2 = "0000000010" then 
                   clk1 <= '0'; 
	               clk2 <= '1';
	               clk3 <= '0';
	               clk4 <= '0'; 
	         elsif key3 = "0000000100" then 
                   clk1 <= '0'; 
	               clk2 <= '0';
	               clk3 <= '1';
	               clk4 <= '0'; 	                             
	         elsif key4 = "0000100000" then 
                   clk1 <= '0'; 
	               clk2 <= '0';
	               clk3 <= '0';
	               clk4 <= '1'; 	                             
             end if;	                                     	                             	         
	  end process;  
      pass <= Qd;
end sample;       
	         
	         