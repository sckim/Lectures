library ieee;
use ieee.std_logic_1164.all;

entity MasterSlave_SRFF is 
       port( S, Clk, R    : in std_logic;
             Q, K            : out std_logic);
end MasterSlave_SRFF;

architecture sample of MasterSlave_SRFF is 
       signal S_m, R_m, Y, Y_bar, S_s, R_s, Qa, Qb : std_logic;
       attribute keep : boolean;
       attribute keep of S_m, R_m, Y, Y_bar, S_s, R_s, Qa, Qb : signal is true;
begin
       S_m <= not(S and Clk);
       R_m <= not(R and Clk);
       Y <= not(S_m and Y_bar);
       Y_bar <= not(R_m and Y);
       K <= Y;
       S_s <= not(Y and not Clk);
       R_s <= not(Y_bar and not Clk);
       Qa <= not(S_s and Qb);
       Qb <= not(R_s and Qa);
       Q <= Qa;
end sample;
       